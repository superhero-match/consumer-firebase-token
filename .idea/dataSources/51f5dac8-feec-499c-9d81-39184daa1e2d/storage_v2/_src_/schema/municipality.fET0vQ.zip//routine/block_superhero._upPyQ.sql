create
    definer = root@localhost procedure block_superhero(IN id varchar(255), IN blocked_at varchar(255))
BEGIN

UPDATE superhero 
SET 
	sueprhero.blocked_at = blocked_at,
	superhero.is_blocked = 1
WHERE superhero.id = id;

END;

