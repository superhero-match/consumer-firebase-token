create definer = root@localhost procedure update_firebase_token(IN sueprhero_id varchar(255), IN firebase_token varchar(255))
BEGIN

UPDATE superhero SET superhero.firebase_token = firebase_token WHERE superhero.id = sueprhero_id COLLATE utf8mb4_0900_ai_ci;

END;

