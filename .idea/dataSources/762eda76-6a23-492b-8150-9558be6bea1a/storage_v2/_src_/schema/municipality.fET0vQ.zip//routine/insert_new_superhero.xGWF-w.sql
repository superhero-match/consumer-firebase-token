create definer = root@localhost procedure insert_new_superhero(IN id varchar(255), IN email varchar(255), IN name varchar(255), IN superhero_name varchar(255), IN main_profile_pic_url varchar(255), IN gender tinyint, IN looking_for_gender tinyint, IN age int, IN looking_for_age_min int, IN looking_for_age_max int, IN looking_for_distance_max int, IN distance_unit varchar(10), IN lat decimal(10,8), IN lon decimal(11,8), IN birthday varchar(50), IN country varchar(255), IN city varchar(255), IN superpower varchar(255), IN account_type varchar(255), IN firebase_token varchar(255), IN is_deleted tinyint, IN deleted_at varchar(255), IN is_blocked tinyint, IN blocked_at varchar(255), IN updated_at varchar(255), IN created_at varchar(255))
BEGIN

INSERT INTO superhero (
		superhero.id, 
		superhero.email,
		superhero.name,
		superhero.superhero_name,
		superhero.main_profile_pic_url,
		superhero.gender,
		superhero.looking_for_gender,
		superhero.age,
		superhero.looking_for_age_min,
		superhero.looking_for_age_max,
		superhero.looking_for_distance_max,
		superhero.distance_unit,
		superhero.lat, 
		superhero.lon,
		superhero.birthday,
		superhero.country,
		superhero.city,
		superhero.superpower,
		superhero.account_type,
		superhero.firebase_token,
		superhero.is_deleted,
		superhero.deleted_at,
		superhero.is_blocked,
		superhero.blocked_at,
		superhero.updated_at,
		superhero.created_at
	)
	VALUES (
		id, 
		email,
		name,
		superhero_name,
		main_profile_pic_url,
		gender,
		looking_for_gender,
		age,
		looking_for_age_min,
		looking_for_age_max,
		looking_for_distance_max,
		distance_unit,
		lat, 
		lon,
		birthday,
		country,
		city,
		superpower,
		account_type,
        firebase_token,
		is_deleted,
		deleted_at,
		is_blocked,
		blocked_at,
		updated_at,
		created_at
    );

END;

